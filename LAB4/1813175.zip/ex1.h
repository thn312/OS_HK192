#ifdef EX1_H
#define EX1_H

void ∗aligned_malloc(unsigned int size , unsigned int align);
void ∗aligned_free(void ∗ptr );
#endif